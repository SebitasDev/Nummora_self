export default function Home() {
  return (
    <div>
      HOLA
    </div>
  );
}
