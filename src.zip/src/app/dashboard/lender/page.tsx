﻿'use client'

import {DashboardTemplate} from "@/components/layouts/DashboardTemplate";
import {useEffect} from "react";
import {walletConnection} from "@/lib/viem/walletConnection";

export default function LenderPage() {
    useEffect(() => {
        walletConnection()
            .then((res) => {
                console.log('Wallet conectada:', res);
            })
            .catch((err) => {
                console.warn('No se pudo conectar la wallet:', err);
            });
    }, []);
    return <DashboardTemplate/>; 
}