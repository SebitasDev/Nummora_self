'use client'

import {DashboardBorrower} from "@/components/layouts/DashboardBorrower";
//Change to commit no mas :P
export default function BorrowerPage() { return <DashboardBorrower/>; }