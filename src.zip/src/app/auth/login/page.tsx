'use client'

import {LoginTemplate} from "@/components/layouts/LoginTemplate";

export default function LoginPage(){
    return <LoginTemplate/>
}